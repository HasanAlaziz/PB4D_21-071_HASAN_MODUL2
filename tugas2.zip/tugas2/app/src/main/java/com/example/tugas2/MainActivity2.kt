package com.example.tugas2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MainActivity2 : AppCompatActivity(), View.OnClickListener {
    private lateinit var buttoninten : Button
    private lateinit var  daftarinten : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        buttoninten = findViewById(R.id.buttoninten)
        buttoninten.setOnClickListener(this)
    }
    override fun onClick(p0: View) {
        when (p0.id){
            R.id.buttoninten ->{
                val intensaja = Intent(this@MainActivity2, receycleview::class.java)
                startActivity(intensaja)
            }
        }
    }

}
