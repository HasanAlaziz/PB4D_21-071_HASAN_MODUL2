package com.example.tugas2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class receycleview : AppCompatActivity() {
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receycleview)

        init()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun init (){
        recyclerView = findViewById(R.id.recycle)

        var data = ArrayList<jilid>()
        data.add(jilid(R.drawable.a, "JUZ 1", "pembelajaran dasar"))
        data.add(jilid(R.drawable.b, "JUZ 2", "pembelajaran dasar"))
        data.add(jilid(R.drawable.c, "JUZ 3", "pembelajaran dasar"))
        data.add(jilid(R.drawable.d, "JUZ 4", "pembelajaran dasar"))
        data.add(jilid(R.drawable.e, "JUZ 5", "pembelajaran dasar"))
        data.add(jilid(R.drawable.f, "JUZ 6", "pembelajaran dasar"))
        data.add(jilid(R.drawable.g, "JUZ 7", "pembelajaran dasar"))
        data.add(jilid(R.drawable.h, "JUZ 8", "pembelajaran dasar"))
        data.add(jilid(R.drawable.i, "JUZ 9", "pembelajaran dasar"))
        data.add(jilid(R.drawable.j, "JUZ 10", "pembelajaran dasar"))
        data.add(jilid(R.drawable.k, "JUZ 11", "pembelajaran dasar"))
        data.add(jilid(R.drawable.l, "JUZ 12", "pembelajaran dasar"))
        data.add(jilid(R.drawable.m, "JUZ 13", "pembelajaran dasar"))
        data.add(jilid(R.drawable.n, "JUZ 14", "pembelajaran dasar"))
        data.add(jilid(R.drawable.o, "JUZ 15", "pembelajaran dasar"))
        data.add(jilid(R.drawable.p, "JUZ 16", "pembelajaran dasar"))
        data.add(jilid(R.drawable.q, "JUZ 17", "pembelajaran dasar"))
        data.add(jilid(R.drawable.r, "JUZ 18", "pembelajaran dasar"))
        data.add(jilid(R.drawable.s, "JUZ 19", "pembelajaran dasar"))
        data.add(jilid(R.drawable.t, "JUZ 20", "pembelajaran dasar"))
        data.add(jilid(R.drawable.u, "JUZ 21", "pembelajaran dasar"))
        data.add(jilid(R.drawable.v, "JUZ 22", "pembelajaran dasar"))
        data.add(jilid(R.drawable.w, "JUZ 23", "pembelajaran dasar"))
        data.add(jilid(R.drawable.x, "JUZ 24", "pembelajaran dasar"))
        data.add(jilid(R.drawable.y, "JUZ 25", "pembelajaran dasar"))
        data.add(jilid(R.drawable.z, "JUZ 26", "pembelajaran dasar"))
        data.add(jilid(R.drawable.za, "JUZ 27", "pembelajaran dasar"))
        data.add(jilid(R.drawable.zb, "JUZ 28", "pembelajaran dasar"))
        data.add(jilid(R.drawable.zc, "JUZ 29", "pembelajaran dasar"))
        data.add(jilid(R.drawable.zd, "JUZ 30", "pembelajaran dasar"))
        adapter = MyAdapter(data)
    }
}