package com.example.tugas2

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ViewHolder (inflater: LayoutInflater, parent: ViewGroup):
    RecyclerView.ViewHolder(inflater.inflate(R.layout.recycle_view_tamplate,
parent, false)) {
    private var imageView: ImageView? = null
    private var title: TextView? = null
    private var sub_title: TextView? = null

    init {
        imageView = itemView.findViewById(R.id.imageView)
        title = itemView.findViewById(R.id.title)
        sub_title = itemView.findViewById(R.id.sub_title)
    }

    fun bind (data: jilid){
        imageView?.setImageResource(data.imageView)
        title?.setText(data.title)
        sub_title?.setText(data.sub_title)
    }
}