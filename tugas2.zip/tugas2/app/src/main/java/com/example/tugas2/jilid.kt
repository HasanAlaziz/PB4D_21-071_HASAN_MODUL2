package com.example.tugas2
data class jilid(val imageView: Int, val title: String, val sub_title: String)